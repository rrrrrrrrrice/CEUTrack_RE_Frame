export CUDA_VISIBLE_DEVICES=6
export PYTHONWARNINGS=ignore::UserWarning
export PYTHONPATH=/wdata/Code/chenqiang/Attack/IouAttack_CEUTrack:$PYTHONPATH
python /wdata/Code/chenqiang/Attack/IouAttack_CEUTrack/tracking/test.py \
ceutrack ceutrack_coesot --dataset coesot --threads 1 --num_gpus 1