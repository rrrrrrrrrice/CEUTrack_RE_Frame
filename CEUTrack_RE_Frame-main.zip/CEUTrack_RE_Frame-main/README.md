# CEUTrack_RE_Frame

整体参考 https://github.com/Event-AHU/COESOT
当前代码基于fe240进行评测
环境安装按下面的步骤
> conda create -n event python=3.8
> 
> conda activate event
> 
> bash install.sh

COESOT数据集matalab脚本参考下面**[链接](https://pan.quark.cn/s/aeb870cc3faa)** 

VisEvent数据集matalab脚本参考下面**[链接](https://pan.quark.cn/s/5f8f9f3ea5e1)**
