from lib.test.evaluation.environment import EnvSettings

def local_env_settings():
    settings = EnvSettings()

    # Set your local paths here.
    attack = 'rgb' # rgb or event or double
    if attack == 'rgb':
        settings.coesot_path = '/wangx/DATA/Dataset/COESOT'
        #settings.fe108_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c0/DATA/chenqiang/COESOT/data/FE108' /evaluation/local.py
        settings.network_path = '/wdata/Code/chenqiang/Attack/IouAttack_CEUTrack/lib/test'    # Where tracking networks are stored.
        settings.prj_dir = '/wdata/Code/chenqiang/Attack/IouAttack_CEUTrack'
        settings.result_plot_path = '/wdata/Code/chenqiang/Attack/IouAttack_CEUTrack/output/test/result_plots'
        settings.results_path = '/wdata/Code/chenqiang/Attack/IouAttack_CEUTrack/output/logs/test'    # Where to store tracking results
        settings.save_dir = '/wdata/Code/chenqiang/Attack/IouAttack_CEUTrack/output'
        settings.segmentation_path = '/wdata/Code/chenqiang/Attack/IouAttack_CEUTrack/output/test/segmentation_results'
        #settings.visevent_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c0/DATA/chenqiang/COESOT/data/VisEvent'
        #settings.visevent_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/chenqiang/COESOT/data/VisEvent'
    elif attack == 'event':
        settings.coesot_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/dataset/COESOT'
        #settings.fe108_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/chenqiang/COESOT/data/FE108'
        settings.network_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/chenqiang/event_attack/event_CEUTrack/pretrained_models'    # Where tracking networks are stored.
        settings.prj_dir = '/wdata/Code/chenqiang/Attack/IouAttack_CEUTrack'
        settings.result_plot_path = '/wdata/Code/chenqiang/Attack/IouAttack_CEUTrack/output/test/result_plots'
        settings.results_path = '/wdata/Code/chenqiang/Attack/IouAttack_CEUTrack/output/test/tracking_results/null_event_t_p' #改这个即可   # Where to store tracking results
        settings.save_dir = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/chenqiang/event_attack/RGB_Event_Frame_Attack/output'
        settings.segmentation_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/chenqiang/event_attack/RGB_Event_Frame_Attack/output/test/segmentation_results'
    else:
        settings.coesot_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/dataset/COESOT'
        #settings.fe108_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/chenqiang/COESOT/data/FE108'
        settings.network_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/chenqiang/event_attack/event_CEUTrack/pretrained_models'    # Where tracking networks are stored.
        settings.prj_dir = '/wdata/Code/chenqiang/Attack/IouAttack_CEUTrack'
        settings.result_plot_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/chenqiang/event_attack/RGB_Event_Frame_Attack/output/test/result_plots'
        settings.results_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/chenqiang/event_attack/RGB_Event_Frame_Attack/output/test/tracking_results/target_attack/double_attack' #改这个即可   # Where to store tracking results
        settings.save_dir = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/chenqiang/event_attack/RGB_Event_Frame_Attack/output'
        settings.segmentation_path = '/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c01/DATA/chenqiang/event_attack/RGB_Event_Frame_Attack/output/test/segmentation_results'
    return settings

